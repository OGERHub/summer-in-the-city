# LST-Materialpaket Köln — Demo-Archiv

Dies ist ein Platzhalterarchiv für die Webseite. Es zeigt die Zielstruktur des späteren Downloadpakets.

Das reale Paket soll enthalten:
- RGB-Luftbild für den Ausdruck
- LST-hot-Karte im gleichen Ausschnitt
- transparente Folienvorlage / Markiervorlage
- Beobachtungsbogen
- vorbereitetes QGIS-Projekt mit lokalen Datenebenen

Für die Grundstunde werden nur Luftbild, LST-Karte und Folie benötigt.
Das QGIS-Projekt ist für Anpassungen und erneuten Export gedacht.
