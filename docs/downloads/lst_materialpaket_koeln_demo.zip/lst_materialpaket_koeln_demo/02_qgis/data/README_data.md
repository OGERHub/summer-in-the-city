Platzhalterordner für lokale RGB- und LST-Daten.
