# Legende LST-hot

Platzhalter für eine druckbare Temperaturlegende.
