# Beobachtungsbogen

| Nr. | markierte Fläche | Oberfläche / Nutzung | LST-Tendenz | plausible Erklärung |
|---|---|---|---|---|
| 1 |  |  | kühl / mittel / heiß |  |
| 2 |  |  | kühl / mittel / heiß |  |
| 3 |  |  | kühl / mittel / heiß |  |
| 4 |  |  | kühl / mittel / heiß |  |
| 5 |  |  | kühl / mittel / heiß |  |
